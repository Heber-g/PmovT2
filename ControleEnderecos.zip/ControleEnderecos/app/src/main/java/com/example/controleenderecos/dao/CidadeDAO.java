package com.example.controleenderecos.dao;

import androidx.room.Query;

public interface CidadeDAO {

}
