package com.example.controleenderecos.dao;

public interface EnderecoDAO {
}
