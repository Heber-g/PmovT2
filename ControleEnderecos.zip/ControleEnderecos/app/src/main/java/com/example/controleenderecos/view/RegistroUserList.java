package com.example.controleenderecos.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.example.controleenderecos.R;
import com.example.controleenderecos.database.LocalDatabase;
import com.example.controleenderecos.databinding.ActivityRegistroUserListBinding;
import com.example.controleenderecos.entity.Usuario;

import java.util.List;

public class RegistroUserList extends AppCompatActivity {
    private ActivityRegistroUserListBinding binding;
    private LocalDatabase db;
    private ListView listViewUser;
    private List<Usuario> usuarioList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegistroUserListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = LocalDatabase.getDatabase(getApplicationContext());
        listViewUser = binding.listViewUsuarios;

        binding.btnVoltarInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}