package com.example.controleenderecos.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.controleenderecos.R;

public class LoginUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_user);
    }
}