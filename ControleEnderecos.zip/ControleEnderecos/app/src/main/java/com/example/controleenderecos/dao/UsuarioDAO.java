package com.example.controleenderecos.dao;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.controleenderecos.entity.Usuario;

import java.util.List;

public interface UsuarioDAO {
    @Query("SELECT * FROM Usuario WHERE usuarioID = :id LIMIT 1")
    Usuario getUsuariosPorID(int id);

    @Query("SELECT * FROM USUARIO")
    List<Usuario> getAll();

    @Update
    void update(Usuario usuario);

    @Insert
    void insert(Usuario usuario);

    @Delete
    void delete(Usuario usuario);

}
